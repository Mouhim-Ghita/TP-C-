﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice3
{
    class InvalidNoteException : Exception
    {
        public InvalidNoteException() : base("La note doit être entre 0 et 20") { }
    }
}
