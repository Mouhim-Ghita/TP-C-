﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice3
{
    class Etudiant
    {
        private string nom;
        private int age;
        private double moyenne;
        public string Nom
        {
            get;set;
        }
        public int Age
        {
            get { return age; }
            set
            {
                if (value <18 || value > 26)
                {
                    throw new InvalidAgeException();
                }
                else
                { age = value; }
            }
                
        }
        public double Moyenne
        {
            get
            {
                return moyenne;             
            }
            set
            {
                if (value < 0 || value > 20)
                { throw new InvalidNoteException(); }
                else
                {
                    moyenne = value;
                }
            }
        }
        public Etudiant() { }
        public Etudiant(string nom, int age,double moyenne)
        {
            this.nom = nom;
            this.Age = age;
            this.Moyenne = moyenne;
           
        }
        public override string ToString()
        {
            return "le nom de l'etudiant est: " + nom + " son âge est : " + age + " sa moyenne est: " + moyenne;
        }
    }
}
