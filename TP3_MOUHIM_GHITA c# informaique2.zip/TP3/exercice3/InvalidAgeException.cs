﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice3
{
    class InvalidAgeException : Exception
    {
        public InvalidAgeException() : base("L'age doit etre entre  18 et 26") { }
    }
}
