﻿using System;

namespace exercice3
{
    class Program
    {
        static void Main(string[] args)
        {
            //question 1
            try
            {
                Console.WriteLine("1-\nentrez un entier");
                int i = int.Parse(Console.ReadLine());
                Console.WriteLine("*****l'entier bien saisie*****");
            }
            catch(Exception)
            {
                Console.WriteLine("la valeur entrée n'est pas entier");
            }

            //question 2
            bool t = true;
            while (t == true)
            {
                try
                {
                    Console.WriteLine("2-\n entrez un entier");
                    int i = int.Parse(Console.ReadLine());
                    Console.WriteLine("*****l'entier bien saisie*****");
                    t = false;
                }
                catch (Exception)
                {
                    Console.WriteLine("la valeur entrée n'est pas entier veuillez la resaisir");
                }
            }
            //question3

            bool p = true;
            while (p == true)
            {
                try
                {
                    Console.WriteLine("3-\n entrez une date sous forrme jj/mm/aaaa");
                    DateTime o = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("*****la date est bien saisie*****");
                    p = false;
                }
                catch (Exception)
                {
                    Console.WriteLine("la date est mal saisie  veuillez la resaisir");
                }
            }
            //question 4:
            Console.WriteLine("4-\n entrez une date de depart sous forrme jj/mm/aaaa");
            DateTime date1 = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("entrz la date d'arrive sous forme jj/mm/aaaa");
            DateTime date2 = DateTime.Parse(Console.ReadLine());
            if (date2 < date1)
            {
                throw new Exception("date d'arrivée que vous avez saisie est inferieur à celle de départ!!!");
            }
            else
            {
                Console.WriteLine("***les deux dates sont valables est bien saisie****");
            }

            //question5
       
            Etudiant student = new Etudiant("ghita", 19, 25);
            string s = student.ToString();
            Console.WriteLine(s);
        }
    }
}
