﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercice4
{
    public partial class FormulaireListe : Form
    {
        public FormulaireListe()
        {
       
            
            InitializeComponent();
            Text = "Liste des matières";
            listGauche.Items.Add("Langage C");
            listGauche.Items.Add("Langage Java");
            listGauche.Items.Add("Langage C++");
            listGauche.Items.Add("Langage C#");
            listGauche.Items.Add("HTML");
            listGauche.Items.Add("CSS");
            listGauche.Items.Add("JavaScript");

        }

       

        private void button10_Click(object sender, EventArgs e)
        {
            int n = listDroit.SelectedIndex;
            string MotStocke;
            if (n != listDroit.Items.Count - 1 && n != -1)
            {
                MotStocke = listDroit.Items[n + 1].ToString();
                listDroit.Items[n + 1] = listDroit.Items[n];
                listDroit.Items[n] = MotStocke;
            }
            else
            {
                if (n == (listDroit.Items.Count - 1))
                    MessageBox.Show("element ne peut pas être déplacé vers le bas");
                if (n == -1)
                    MessageBox.Show("aucun element n'est selctioné!!!");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            listGauche.Sorted = true;
            string[] t = new string[listGauche.Items.Count];
            for (int i = listGauche.Items.Count, j = 0; i > 0; i--, j++)
            {
                t[j] = listGauche.Items[i - 1].ToString();
            }
            listGauche.Items.Clear();
            listGauche.Sorted = false;
            listGauche.Items.AddRange(t);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void GaucheVersDroit_Click(object sender, EventArgs e)
        {
            try
            {
                listDroit.Items.Add(listGauche.SelectedItem);
                listGauche.Items.Remove(listGauche.SelectedItem);
            }
            catch(Exception )
            {
                MessageBox.Show("aucun element n'est sélectionné");
            }
        }

        private void gaucheVerDroit_Click(object sender, EventArgs e)
        {
            try
            {
                listDroit.Items.AddRange(listGauche.Items);
                listGauche.Items.Clear();
            }
            catch(Exception)
            {
                MessageBox.Show("aucun element a transferer");
            }
        }

        private void RightToLeftOne_Click(object sender, EventArgs e)
        {
            try
            {
                listGauche.Items.Add(listDroit.SelectedItem);
                listDroit.Items.Remove(listDroit.SelectedItem);
            }
            catch (Exception)
            {
                MessageBox.Show("aucun element n'est sélectionné");
            }
        }

        private void RightToLeft_Click(object sender, EventArgs e)
        {
            try
            {
                listGauche.Items.AddRange(listDroit.Items);
                listDroit.Items.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("aucun element a transferer");
            }
        }

        private void TriOrdonne1_Click(object sender, EventArgs e)
        {
            //ici la fonction fonctionne dans un seul clik 
            /*string caption = "Message";
            if (listGauche.Items.Count >= 1)
                listGauche.Sorted = true;
            else
                MessageBox.Show("aucun élement à trier", caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            */
            //la fonction fonctionne apres plusieurs clicks
            if (listGauche.Items.Count >= 1)
            {
                string[] t = new string[listGauche.Items.Count];
                for (int i = 0; i < t.Length; i++)
                {
                    t[i] = listGauche.Items[i].ToString();
                }
                listGauche.Items.Clear();
                listGauche.Items.AddRange(t);
                listGauche.Sorted = true;
            }
            else
                MessageBox.Show("aucun élement à trier", "message ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void TriOrdonne2_Click(object sender, EventArgs e)
        {
            string caption = "Message";
            if (listDroit.Items.Count >= 1)
            {
                string[] t = new string[listDroit.Items.Count];
                for (int i = 0; i < t.Length; i++)
                {
                    t[i] = listDroit.Items[i].ToString();
                }
                listDroit.Items.Clear();
                listDroit.Items.AddRange(t);
                listDroit.Sorted = true;
            }
            else
                MessageBox.Show("aucun élement à trier", caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void DownUp_Click(object sender, EventArgs e)
        {
            int n = listGauche.SelectedIndex;
            string MotStocke;
            if(n!=0 &&n!=-1)
            {
                MotStocke = listGauche.Items[n - 1].ToString();
                listGauche.Items[n - 1] = listGauche.Items[n];
                listGauche.Items[n] = MotStocke;
            }
            else
            {
                if (n == 0)
                    MessageBox.Show("element ne peut pas être déplacé vers le haut");
                if(n==-1)
                    MessageBox.Show("aucun element n'est selctioné!!!");
            }
        }

        private void BasHaut_Click(object sender, EventArgs e)
        {
            int n = listDroit.SelectedIndex;
            string MotStocke;
            if (n != 0 && n != -1)
            {
                MotStocke = listDroit.Items[n - 1].ToString();
                listDroit.Items[n - 1] = listDroit.Items[n];
                listDroit.Items[n] = MotStocke;
            }
            else
            {
                if (n == 0)
                    MessageBox.Show("element ne peut pas être déplacé vers le haut");
                if (n == -1)
                    MessageBox.Show("aucun element n'est selctioné!!!");
            }
        }

        private void UpDown_Click(object sender, EventArgs e)
        {
            int n = listGauche.SelectedIndex;
            string MotStocke;
            if (n != listGauche.Items.Count-1 && n != -1)
            {
                MotStocke = listGauche.Items[n +1].ToString();
                listGauche.Items[n + 1] = listGauche.Items[n];
                listGauche.Items[n] = MotStocke;
            }
            else
            {
                if (n == listGauche.Items.Count-1)
                    MessageBox.Show("element ne peut pas être déplacé vers le bas");
                if (n == -1)
                    MessageBox.Show("aucun element n'est selctioné!!!");
            }
        }

        private void TriDesordonne2_Click(object sender, EventArgs e)
        {
            listDroit.Sorted = true;
            string[] t = new string[listDroit.Items.Count];
            for (int i = listDroit.Items.Count, j = 0; i > 0; i--, j++)
            {
                t[j] = listDroit.Items[i - 1].ToString();
            }
            listDroit.Items.Clear();
            listDroit.Sorted = false;
            listDroit.Items.AddRange(t);
        }
    }
}
