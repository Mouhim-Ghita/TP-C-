﻿namespace exercice4
{
    partial class FormulaireListe
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormulaireListe));
            this.listGauche = new System.Windows.Forms.ListBox();
            this.listDroit = new System.Windows.Forms.ListBox();
            this.GaucheVersDroit = new System.Windows.Forms.Button();
            this.gaucheVerDroit = new System.Windows.Forms.Button();
            this.RightToLeftOne = new System.Windows.Forms.Button();
            this.RightToLeft = new System.Windows.Forms.Button();
            this.DownUp = new System.Windows.Forms.Button();
            this.UpDown = new System.Windows.Forms.Button();
            this.TriOrdonne1 = new System.Windows.Forms.Button();
            this.TriDesordonne1 = new System.Windows.Forms.Button();
            this.BasHaut = new System.Windows.Forms.Button();
            this.HautBas = new System.Windows.Forms.Button();
            this.TriOrdonne2 = new System.Windows.Forms.Button();
            this.TriDesordonne2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listGauche
            // 
            this.listGauche.FormattingEnabled = true;
            this.listGauche.ItemHeight = 15;
            this.listGauche.Location = new System.Drawing.Point(24, 12);
            this.listGauche.Name = "listGauche";
            this.listGauche.Size = new System.Drawing.Size(120, 184);
            this.listGauche.TabIndex = 0;
            this.listGauche.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // listDroit
            // 
            this.listDroit.FormattingEnabled = true;
            this.listDroit.ItemHeight = 15;
            this.listDroit.Location = new System.Drawing.Point(432, 12);
            this.listDroit.Name = "listDroit";
            this.listDroit.Size = new System.Drawing.Size(120, 184);
            this.listDroit.TabIndex = 0;
            // 
            // GaucheVersDroit
            // 
            this.GaucheVersDroit.Location = new System.Drawing.Point(258, 25);
            this.GaucheVersDroit.Name = "GaucheVersDroit";
            this.GaucheVersDroit.Size = new System.Drawing.Size(33, 23);
            this.GaucheVersDroit.TabIndex = 1;
            this.GaucheVersDroit.Text = ">";
            this.GaucheVersDroit.UseVisualStyleBackColor = true;
            this.GaucheVersDroit.Click += new System.EventHandler(this.GaucheVersDroit_Click);
            // 
            // gaucheVerDroit
            // 
            this.gaucheVerDroit.Location = new System.Drawing.Point(258, 54);
            this.gaucheVerDroit.Name = "gaucheVerDroit";
            this.gaucheVerDroit.Size = new System.Drawing.Size(33, 23);
            this.gaucheVerDroit.TabIndex = 1;
            this.gaucheVerDroit.Text = ">>";
            this.gaucheVerDroit.UseVisualStyleBackColor = true;
            this.gaucheVerDroit.Click += new System.EventHandler(this.gaucheVerDroit_Click);
            // 
            // RightToLeftOne
            // 
            this.RightToLeftOne.Location = new System.Drawing.Point(258, 92);
            this.RightToLeftOne.Name = "RightToLeftOne";
            this.RightToLeftOne.Size = new System.Drawing.Size(33, 23);
            this.RightToLeftOne.TabIndex = 1;
            this.RightToLeftOne.Text = "<";
            this.RightToLeftOne.UseVisualStyleBackColor = true;
            this.RightToLeftOne.Click += new System.EventHandler(this.RightToLeftOne_Click);
            // 
            // RightToLeft
            // 
            this.RightToLeft.Location = new System.Drawing.Point(258, 132);
            this.RightToLeft.Name = "RightToLeft";
            this.RightToLeft.Size = new System.Drawing.Size(33, 23);
            this.RightToLeft.TabIndex = 1;
            this.RightToLeft.Text = "<<";
            this.RightToLeft.UseVisualStyleBackColor = true;
            this.RightToLeft.Click += new System.EventHandler(this.RightToLeft_Click);
            // 
            // DownUp
            // 
            this.DownUp.Location = new System.Drawing.Point(24, 221);
            this.DownUp.Name = "DownUp";
            this.DownUp.Size = new System.Drawing.Size(47, 23);
            this.DownUp.TabIndex = 1;
            this.DownUp.Text = "↑";
            this.DownUp.UseVisualStyleBackColor = true;
            this.DownUp.Click += new System.EventHandler(this.DownUp_Click);
            // 
            // UpDown
            // 
            this.UpDown.Location = new System.Drawing.Point(97, 221);
            this.UpDown.Name = "UpDown";
            this.UpDown.Size = new System.Drawing.Size(47, 23);
            this.UpDown.TabIndex = 1;
            this.UpDown.Text = "↓";
            this.UpDown.UseVisualStyleBackColor = true;
            this.UpDown.Click += new System.EventHandler(this.UpDown_Click);
            // 
            // TriOrdonne1
            // 
            this.TriOrdonne1.Location = new System.Drawing.Point(24, 278);
            this.TriOrdonne1.Name = "TriOrdonne1";
            this.TriOrdonne1.Size = new System.Drawing.Size(47, 23);
            this.TriOrdonne1.TabIndex = 1;
            this.TriOrdonne1.Text = "A-Z";
            this.TriOrdonne1.UseVisualStyleBackColor = true;
            this.TriOrdonne1.Click += new System.EventHandler(this.TriOrdonne1_Click);
            // 
            // TriDesordonne1
            // 
            this.TriDesordonne1.Location = new System.Drawing.Point(97, 278);
            this.TriDesordonne1.Name = "TriDesordonne1";
            this.TriDesordonne1.Size = new System.Drawing.Size(47, 23);
            this.TriDesordonne1.TabIndex = 1;
            this.TriDesordonne1.Text = "Z-A";
            this.TriDesordonne1.UseVisualStyleBackColor = true;
            this.TriDesordonne1.Click += new System.EventHandler(this.button8_Click);
            // 
            // BasHaut
            // 
            this.BasHaut.Location = new System.Drawing.Point(432, 221);
            this.BasHaut.Name = "BasHaut";
            this.BasHaut.Size = new System.Drawing.Size(47, 23);
            this.BasHaut.TabIndex = 1;
            this.BasHaut.Text = "↑";
            this.BasHaut.UseVisualStyleBackColor = true;
            this.BasHaut.Click += new System.EventHandler(this.BasHaut_Click);
            // 
            // HautBas
            // 
            this.HautBas.Location = new System.Drawing.Point(508, 221);
            this.HautBas.Name = "HautBas";
            this.HautBas.Size = new System.Drawing.Size(44, 23);
            this.HautBas.TabIndex = 1;
            this.HautBas.Text = "↓";
            this.HautBas.UseVisualStyleBackColor = true;
            this.HautBas.Click += new System.EventHandler(this.button10_Click);
            // 
            // TriOrdonne2
            // 
            this.TriOrdonne2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.TriOrdonne2.Location = new System.Drawing.Point(432, 278);
            this.TriOrdonne2.Name = "TriOrdonne2";
            this.TriOrdonne2.Size = new System.Drawing.Size(47, 23);
            this.TriOrdonne2.TabIndex = 1;
            this.TriOrdonne2.Text = "A-Z";
            this.TriOrdonne2.UseVisualStyleBackColor = true;
            this.TriOrdonne2.Click += new System.EventHandler(this.TriOrdonne2_Click);
            // 
            // TriDesordonne2
            // 
            this.TriDesordonne2.Location = new System.Drawing.Point(508, 278);
            this.TriDesordonne2.Name = "TriDesordonne2";
            this.TriDesordonne2.Size = new System.Drawing.Size(44, 23);
            this.TriDesordonne2.TabIndex = 1;
            this.TriDesordonne2.Text = "Z-A";
            this.TriDesordonne2.UseVisualStyleBackColor = true;
            this.TriDesordonne2.Click += new System.EventHandler(this.TriDesordonne2_Click);
            // 
            // FormulaireListe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(675, 450);
            this.Controls.Add(this.TriDesordonne2);
            this.Controls.Add(this.TriOrdonne2);
            this.Controls.Add(this.HautBas);
            this.Controls.Add(this.BasHaut);
            this.Controls.Add(this.TriDesordonne1);
            this.Controls.Add(this.TriOrdonne1);
            this.Controls.Add(this.UpDown);
            this.Controls.Add(this.DownUp);
            this.Controls.Add(this.RightToLeft);
            this.Controls.Add(this.RightToLeftOne);
            this.Controls.Add(this.gaucheVerDroit);
            this.Controls.Add(this.GaucheVersDroit);
            this.Controls.Add(this.listDroit);
            this.Controls.Add(this.listGauche);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "FormulaireListe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listGauche;
        private System.Windows.Forms.ListBox listDroit;
        private System.Windows.Forms.Button GaucheVersDroit;
        private System.Windows.Forms.Button gaucheVerDroit;
        private System.Windows.Forms.Button RightToLeftOne;
        private System.Windows.Forms.Button RightToLeft;
        private System.Windows.Forms.Button DownUp;
        private System.Windows.Forms.Button UpDown;
        private System.Windows.Forms.Button TriOrdonne1;
        private System.Windows.Forms.Button TriDesordonne1;
        private System.Windows.Forms.Button BasHaut;
        private System.Windows.Forms.Button HautBas;
        private System.Windows.Forms.Button TriOrdonne2;
        private System.Windows.Forms.Button TriDesordonne2;
    }
}

