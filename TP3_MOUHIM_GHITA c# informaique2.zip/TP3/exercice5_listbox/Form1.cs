﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercice5_listbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Add("Salade");
            listBox1.Items.Add("Fromage");
            listBox1.Items.Add("Poulet Ruits");
            listBox1.Items.Add("Poisson");
            listBox1.Items.Add("Dessert");
            listBox1.Items.Add("Café");
            listBox1.SelectionMode = SelectionMode.MultiSimple;
        }



        private void button1_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedItems.Count != 0)
            {
                string menu = "";
                for (int i = 0; i < listBox1.SelectedItems.Count; i++)
                {
                    menu = menu + listBox1.SelectedItems[i] + "\n";
                }
                MessageBox.Show("vous avez commander " + menu, "Menu", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("vous n'avez rien selectionné ", "Menu", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

    }
}
