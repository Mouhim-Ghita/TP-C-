﻿using System;
using System.Collections.Generic;
namespace exercice_1
{
    class Program
    {
        public static void TrouverTaille(List<string> l)
        {
            string[] tableau = l.ToArray();
            List<string> m = l.FindAll(tableau=>tableau.Length == 5);
            foreach (string i in m)
                Console.WriteLine(i);
        }
        public static void TrouverFin(List<string> l)
        {
            string[] tableau = l.ToArray();
            List<string> m = l.FindAll(tableau => tableau.EndsWith("ge"));
            foreach (string i in m)
                Console.WriteLine(i);
        }
        

        static void Main(string[] args)
        {
            Console.WriteLine("\t*****liste des couleurs*****");
            List<string> listeCouleurs = new List<string> { "violet", "indigo", "bleu", "vert", "jaune", "orange", "rouge" };
            listeCouleurs.Sort();
            foreach(string i in listeCouleurs)
            { Console.WriteLine(i); }
            //le nombre des elements:
            int n = listeCouleurs.Count;
            Console.WriteLine("le nombre des couleurs dans la liste est {0}", n);

            Console.WriteLine("\n ajout du couleur marron");
            listeCouleurs.Add("marron");
            listeCouleurs.Sort();
            foreach (string i in listeCouleurs)
            { Console.WriteLine(i); }
            //le nombre des elements:
            int a = listeCouleurs.Count;
            Console.WriteLine("le nombre des couleurs dans la liste est {0}", a);

           
            
            //le teste :
            Console.WriteLine("\nle test sur la couleur Rose:");
                if (listeCouleurs.Contains("rose"))
                {
                    Console.WriteLine("la couleur rose existe");

                }
                else
                    Console.WriteLine("\nla couleur rose n'existe pas");
            //couleurs de taille 5:
            Console.WriteLine("\n les couleurs de taille 5 sont");
            TrouverTaille(listeCouleurs);
            //couleurs se termine par ge
            Console.WriteLine("\n les couleurs terminant par ge sont: ");
            TrouverFin(listeCouleurs);
            
        }
    }
}
