﻿using System;
using System.Collections.Generic;

namespace exercice2
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> ouvrirAvec = new Dictionary<string, string>();
            ouvrirAvec.Add(".txt", "notepad.exe");
            ouvrirAvec.Add(".pdf", "AdobeAcrobat.exe");
            ouvrirAvec.Add(".m", "matlab.exe");

            try
            {
                ouvrirAvec.Add(".txt", "blocnotes.exe");
                Console.Write("fichier bien ajoute");
            }
            catch(Exception)
            {
                Console.Write("ce type de clès existe déja vous ne pouvez pas le faire");
            }
            //le parcours de dictionnaire
            Console.WriteLine("\n****** affichhage des valeurs et leurs clefs*****");
            foreach(KeyValuePair<string,string> c in ouvrirAvec)
            {
                Console.WriteLine("La valeur associé à la clef \"{0}\" est \"{1}\"", c.Key, c.Value);
            }
            //chagement du programme d'une clef
            ouvrirAvec[".txt"] = "Word.exe";
            Console.WriteLine("\n****** affichhage des valeurs et leurs clefs après le changement*****");
            foreach (KeyValuePair<string, string> c in ouvrirAvec)
            {
                Console.WriteLine("La valeur associé à la clef \"{0}\" est \"{1}\"", c.Key, c.Value);
            }
            Console.WriteLine("****affichage d'une clef inexistente****");
            try
            {
               Console.WriteLine( ouvrirAvec[".cs"]+"clefs existente");
            }
            catch(Exception)
            {
                Console.WriteLine("la clefs '.cs' n'existe pas dans le dictionnaire");
            }
            Console.WriteLine("\n**** utilisation de TryGetValue***");
            Console.Write("entrez une clefs: ");
            string s = Console.ReadLine();
            string valeur;
            if(ouvrirAvec.TryGetValue(s,out valeur))
            {
                Console.WriteLine("la valeur de la clef \"{0}\" est: \"{1}\" ", s, valeur);
            }
            else
            {
                Console.WriteLine("la clef \"{0}\" inexistente donc la valeur n'existe pas", s);

            }

            Console.WriteLine("\n**** utilisation de ContainsKey***");
            Console.Write("entrez une clefs: ");
            string k = Console.ReadLine();
            if(ouvrirAvec.ContainsKey(k))
            {
                Console.WriteLine("la clef \"{0}\"  existente", k);

            }
            else
            {
                Console.WriteLine("la clef \"{0}\" inexistente", k);
            }

            Console.WriteLine("\n*** suppression d'une paire clef/valeur***");
            Console.Write("entrez la clès à supprimer ");
            string o = Console.ReadLine();
            if(ouvrirAvec.Remove(o))
            {
                Console.WriteLine("suppression reussie de \"{0}\"",o);
            }
            else
            {
                Console.WriteLine("suppression erronée");
            }
            Console.WriteLine("\n *** le nombre de paires stocke ***");
            Console.WriteLine("dans notre dictionnaire nous avons \"{0}\" paires", ouvrirAvec.Count);

          //suppression
            ouvrirAvec.Clear();

            Console.WriteLine("\n *** le nombre de paires stocke après la suppression ***");
            Console.WriteLine("dans notre dictionnaire nous avons \"{0}\" paires", ouvrirAvec.Count);


        }
    }
}
