﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercice5_checkbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CocherToutButton_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = true;
            checkBox2.Checked = true;
            checkBox3.Checked = true;
            checkBox4.Checked = true;
            checkBox5.Checked = true;
            checkBox6.Checked = true;
            checkBox7.Checked = true;
            checkBox8.Checked = true;
            checkBox9.Checked = true;
            checkBox10.Checked = true;
        }

        private void DecocherToutButton_Click(object sender, EventArgs e)
        {
            checkBox1.Checked =false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
            checkBox7.Checked = false;
            checkBox8.Checked = false;
            checkBox9.Checked = false;
            checkBox10.Checked = false;
        }

        private void QuitterButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CommanderButton_Click(object sender, EventArgs e)
        {
           
            string menu = "";
            if (checkBox1.Checked)
                menu += checkBox1.Text+"\n";
            if (checkBox2.Checked)
                menu += checkBox2.Text + "\n";
            if (checkBox3.Checked)
                menu += checkBox3.Text + "\n";
            if (checkBox4.Checked)
                menu += checkBox4.Text + "\n";
            if (checkBox5.Checked)
                menu += checkBox5.Text + "\n";
            if (checkBox6.Checked)
                menu += checkBox6.Text + "\n";
            if (checkBox7.Checked)
                menu += checkBox7.Text + "\n";
            if (checkBox8.Checked)
                menu += checkBox8.Text + "\n";
            if (checkBox9.Checked)
                menu += checkBox9.Text + "\n";
            if (checkBox10.Checked)
                menu += checkBox10.Text + "\n";
            

            MessageBox.Show("Votre menu est:\n\n" + menu, "Menu", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.AcceptButton = CommanderButton;
            this.CancelButton = QuitterButton;

        }
    }
}
