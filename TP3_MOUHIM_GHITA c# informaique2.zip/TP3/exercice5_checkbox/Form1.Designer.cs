﻿namespace exercice5_checkbox
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.CocherToutButton = new System.Windows.Forms.Button();
            this.DecocherToutButton = new System.Windows.Forms.Button();
            this.CommanderButton = new System.Windows.Forms.Button();
            this.QuitterButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox10);
            this.groupBox1.Controls.Add(this.checkBox9);
            this.groupBox1.Controls.Add(this.checkBox8);
            this.groupBox1.Controls.Add(this.checkBox7);
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Location = new System.Drawing.Point(133, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(389, 212);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menu";
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(281, 178);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(50, 19);
            this.checkBox10.TabIndex = 0;
            this.checkBox10.Text = "Café";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(281, 145);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(64, 19);
            this.checkBox9.TabIndex = 0;
            this.checkBox9.Text = "Dessert";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(281, 105);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(84, 19);
            this.checkBox8.TabIndex = 0;
            this.checkBox8.Text = "Frommage";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(281, 64);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(60, 19);
            this.checkBox7.TabIndex = 0;
            this.checkBox7.Text = "Salade";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(281, 22);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(67, 19);
            this.checkBox6.TabIndex = 0;
            this.checkBox6.Text = "Poisson";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(25, 178);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(96, 19);
            this.checkBox5.TabIndex = 0;
            this.checkBox5.Text = "Poulet Routis";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(25, 145);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(87, 19);
            this.checkBox4.TabIndex = 0;
            this.checkBox4.Text = "Charcuterie";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(25, 105);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(65, 19);
            this.checkBox3.TabIndex = 0;
            this.checkBox3.Text = "Curdite";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(25, 64);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(67, 19);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "Portage";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(25, 22);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(65, 19);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Aperitif";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // CocherToutButton
            // 
            this.CocherToutButton.Location = new System.Drawing.Point(133, 231);
            this.CocherToutButton.Name = "CocherToutButton";
            this.CocherToutButton.Size = new System.Drawing.Size(116, 23);
            this.CocherToutButton.TabIndex = 1;
            this.CocherToutButton.Text = "CocherTout";
            this.CocherToutButton.UseVisualStyleBackColor = true;
            this.CocherToutButton.Click += new System.EventHandler(this.CocherToutButton_Click);
            // 
            // DecocherToutButton
            // 
            this.DecocherToutButton.Location = new System.Drawing.Point(384, 231);
            this.DecocherToutButton.Name = "DecocherToutButton";
            this.DecocherToutButton.Size = new System.Drawing.Size(138, 23);
            this.DecocherToutButton.TabIndex = 1;
            this.DecocherToutButton.Text = "Décocher Tout";
            this.DecocherToutButton.UseVisualStyleBackColor = true;
            this.DecocherToutButton.Click += new System.EventHandler(this.DecocherToutButton_Click);
            // 
            // CommanderButton
            // 
            this.CommanderButton.Location = new System.Drawing.Point(158, 277);
            this.CommanderButton.Name = "CommanderButton";
            this.CommanderButton.Size = new System.Drawing.Size(91, 23);
            this.CommanderButton.TabIndex = 1;
            this.CommanderButton.Text = "Commander";
            this.CommanderButton.UseVisualStyleBackColor = true;
            this.CommanderButton.Click += new System.EventHandler(this.CommanderButton_Click);
            // 
            // QuitterButton
            // 
            this.QuitterButton.Location = new System.Drawing.Point(384, 277);
            this.QuitterButton.Name = "QuitterButton";
            this.QuitterButton.Size = new System.Drawing.Size(75, 23);
            this.QuitterButton.TabIndex = 1;
            this.QuitterButton.Text = "Quitter";
            this.QuitterButton.UseVisualStyleBackColor = true;
            this.QuitterButton.Click += new System.EventHandler(this.QuitterButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 450);
            this.Controls.Add(this.QuitterButton);
            this.Controls.Add(this.CommanderButton);
            this.Controls.Add(this.DecocherToutButton);
            this.Controls.Add(this.CocherToutButton);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button CocherToutButton;
        private System.Windows.Forms.Button DecocherToutButton;
        private System.Windows.Forms.Button CommanderButton;
        private System.Windows.Forms.Button QuitterButton;
    }
}

