﻿namespace exercice6_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.minute = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.seconde = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.miliseconde = new System.Windows.Forms.Label();
            this.Demarer = new System.Windows.Forms.Button();
            this.Arreter = new System.Windows.Forms.Button();
            this.Effacer = new System.Windows.Forms.Button();
            this.Tour = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(476, 73);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 169);
            this.listBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(476, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Captures";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // minute
            // 
            this.minute.AutoSize = true;
            this.minute.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.minute.Location = new System.Drawing.Point(98, 186);
            this.minute.Name = "minute";
            this.minute.Size = new System.Drawing.Size(47, 36);
            this.minute.TabIndex = 2;
            this.minute.Text = "00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(142, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 36);
            this.label3.TabIndex = 3;
            this.label3.Text = ":";
            // 
            // seconde
            // 
            this.seconde.AutoSize = true;
            this.seconde.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.seconde.Location = new System.Drawing.Point(162, 186);
            this.seconde.Name = "seconde";
            this.seconde.Size = new System.Drawing.Size(47, 36);
            this.seconde.TabIndex = 3;
            this.seconde.Text = "00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(206, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 36);
            this.label5.TabIndex = 3;
            this.label5.Text = ":";
            // 
            // miliseconde
            // 
            this.miliseconde.AutoSize = true;
            this.miliseconde.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.miliseconde.Location = new System.Drawing.Point(225, 186);
            this.miliseconde.Name = "miliseconde";
            this.miliseconde.Size = new System.Drawing.Size(47, 36);
            this.miliseconde.TabIndex = 3;
            this.miliseconde.Text = "00";
            // 
            // Demarer
            // 
            this.Demarer.Location = new System.Drawing.Point(83, 294);
            this.Demarer.Name = "Demarer";
            this.Demarer.Size = new System.Drawing.Size(75, 23);
            this.Demarer.TabIndex = 4;
            this.Demarer.Text = "Demarer";
            this.Demarer.UseVisualStyleBackColor = true;
            this.Demarer.Click += new System.EventHandler(this.Demarer_Click);
            // 
            // Arreter
            // 
            this.Arreter.Location = new System.Drawing.Point(186, 294);
            this.Arreter.Name = "Arreter";
            this.Arreter.Size = new System.Drawing.Size(75, 23);
            this.Arreter.TabIndex = 5;
            this.Arreter.Text = "Arrêter";
            this.Arreter.UseVisualStyleBackColor = true;
            this.Arreter.Click += new System.EventHandler(this.Arreter_Click);
            // 
            // Effacer
            // 
            this.Effacer.Location = new System.Drawing.Point(296, 294);
            this.Effacer.Name = "Effacer";
            this.Effacer.Size = new System.Drawing.Size(75, 23);
            this.Effacer.TabIndex = 6;
            this.Effacer.Text = "Effacer";
            this.Effacer.UseVisualStyleBackColor = true;
            this.Effacer.Click += new System.EventHandler(this.Effacer_Click);
            // 
            // Tour
            // 
            this.Tour.Location = new System.Drawing.Point(388, 294);
            this.Tour.Name = "Tour";
            this.Tour.Size = new System.Drawing.Size(75, 23);
            this.Tour.TabIndex = 7;
            this.Tour.Text = "Tour";
            this.Tour.UseVisualStyleBackColor = true;
            this.Tour.Click += new System.EventHandler(this.Tour_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(23, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(399, 73);
            this.label2.TabIndex = 8;
            this.label2.Text = "Chronometre";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(618, 366);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Tour);
            this.Controls.Add(this.Effacer);
            this.Controls.Add(this.Arreter);
            this.Controls.Add(this.Demarer);
            this.Controls.Add(this.miliseconde);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.seconde);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.minute);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label minute;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label seconde;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label miliseconde;
        private System.Windows.Forms.Button Demarer;
        private System.Windows.Forms.Button Arreter;
        private System.Windows.Forms.Button Effacer;
        private System.Windows.Forms.Button Tour;
        private System.Windows.Forms.Label label2;
    }
}

