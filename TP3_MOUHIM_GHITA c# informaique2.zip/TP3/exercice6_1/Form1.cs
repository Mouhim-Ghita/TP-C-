﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercice6_1
{
    public partial class Form1 : Form
    {
        int mili_seconde, _seconde, _minute, tour;

      

        public Form1()
        {
            InitializeComponent();
        }

        private void Arreter_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void Effacer_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            mili_seconde = 0;
            _seconde = 0;
            _minute = 0;
            miliseconde.Text = "00";
            seconde.Text = "00";
            minute.Text = "00";
            listBox1.Items.Clear();
            
        }

        private void Tour_Click(object sender, EventArgs e)
        {
            tour++;
            listBox1.Items.Add("tour" + tour + ": " + minute.Text + ":" + seconde.Text + ":" + miliseconde.Text);
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            if(timer1.Enabled==true)
            {
                mili_seconde++;
                if(mili_seconde==100)
                {
                    _seconde++;
                    mili_seconde = 0;
                    if(_seconde==60)
                    {
                        _minute++;
                        _seconde = 0;
                    }
                }

            }
            miliseconde.Text = string.Format("{0:00}", mili_seconde);
            seconde.Text = string.Format("{0:00}", _seconde);
            minute.Text = string.Format("{0:00}", _minute);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1;
            mili_seconde = 0;
            _minute = 0;
            _seconde = 0;
            tour = 0; 
        }

        private void Demarer_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
