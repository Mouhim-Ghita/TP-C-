﻿using System;

namespace exercice5
{
    class Program
    {
        static void Main(string[] args)
        {
            CrieAnimeaux[] animmeaux = new CrieAnimeaux[3];
            animmeaux[0] = new Chien();
            animmeaux[1] = new Chat();
            animmeaux[2] = new lappin();
            for (int i = 0; i < animmeaux.Length; i++)
                animmeaux[i].crier();
        }
    }
}
