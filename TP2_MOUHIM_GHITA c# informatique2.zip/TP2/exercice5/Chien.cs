﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice5
{
    class Chien:CrieAnimeaux
    {
        public void crier()
        {
            Console.WriteLine("le chien aboie");
        }
    }
}
