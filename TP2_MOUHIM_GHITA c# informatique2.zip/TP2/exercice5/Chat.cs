﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice5
{
    class Chat:CrieAnimeaux
    {
        public void crier()
        {
            Console.WriteLine("le chat miaule");
        }
    }
}
