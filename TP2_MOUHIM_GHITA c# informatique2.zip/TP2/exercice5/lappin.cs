﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice5
{
    class lappin:CrieAnimeaux
    {
        public void crier()
        {
            Console.WriteLine("le lappin est muet ");
        }
    }
}
