﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice6
{
    class Compte
    {
        private  double solde;
        private  static int number=0;
        private readonly int code;
       private Client proprietaire;
        public double Solde
        { get; }
        public int Code
        { get; }
        public Client Proprietaire
        { get; set; }

        public Compte(Client proprietaire,double solde)
        {
            number++;
            this.proprietaire = proprietaire;
            code = number;
            this.solde = solde;
        }
        public void Crediter(double somme)
        {
            this.solde = solde + somme;
            Console.WriteLine("credit bien fait");
        }
        public void Crediter(Compte compte,double somme)
        {
            if(compte.solde>=somme)
            {
                compte.solde = compte.solde - somme;
                this.solde += somme;
                Console.WriteLine("credit bien fait");
            }
            else { Console.WriteLine("crédit mal fait"); }
        }

        public void Debiter(double somme)
        {
            if (this.solde >= somme)
            {
                this.solde = this.solde - somme;
                Console.WriteLine("debit bien fait");
            }
            else
                Console.WriteLine("debit mal fait");
        }
        public void Debiter(Compte compte,double somme)
        {
            if (this.solde >= somme)
            {
                this.solde = this.solde - somme;
                compte.solde += somme;
                Console.WriteLine("debit bien fait");
            }
            else
                Console.WriteLine("debit mal fait");
        }
        public void afficher()
        {
            Console.WriteLine("le compte de code {0} et de solde {1} appartient à:",code,solde);
            proprietaire.afficher();

        }
        public  static void NCompte()
        {
            Console.WriteLine("le nombre des comptes est:" + number);
        }

    }
}
