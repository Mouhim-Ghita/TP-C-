﻿using System;

namespace exercice6
{
    class Program
    {
        static void Main(string[] args)
        {
            Client c1 = new Client("C987654", "rhiati ", "fatiha","072135489");
            Client c = new Client("C123456", "mouhim", "ghita", "0675217");
            Compte compte = new Compte(c, 1850.50);
            Compte compte1 = new Compte(c1, 25000);
            compte.afficher();

            

            //crediter par  les  deux methodes:

            Console.WriteLine("\ncrediter methode1");
            Console.WriteLine("entrez la somme à crediter:");
            double s = double.Parse(Console.ReadLine());
            compte.Crediter(s);
            compte.afficher();
            Console.WriteLine("\ncompte2");
            compte1.afficher();
            Console.WriteLine("\ncrediter methode2");
            Console.WriteLine("entrez la somme à crediter:");
            double p= double.Parse(Console.ReadLine());
            compte.Crediter(compte1,p);
            compte.afficher();
            compte1.afficher();
            Console.WriteLine("\n le  debit:");
            //debiter par  les deux methodes: 
            Console.WriteLine("\ndebiter methode1");
            Console.WriteLine("entrez la somme à debiter:");
            double e = double.Parse(Console.ReadLine());
            compte.Debiter(e);
            compte.afficher();
            Console.WriteLine("\ncompte2");
            compte1.afficher();
            Console.WriteLine("\ncrediter methode2");
            Console.WriteLine("entrez la somme à debite:");
            double o= double.Parse(Console.ReadLine());
            compte.Debiter(compte1, o);
            compte.afficher();
            compte1.afficher();

            //nombre de compte:
            Console.WriteLine("\n dans cet exercice nous avons");
            Compte.NCompte();
        }
    }
}
