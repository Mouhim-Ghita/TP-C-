﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice6
{
    class Client
    {
        private string _CIN, nom, prenom;
        private string telephone;
        public string Cin
        {
            get;set;
        }
        public string Nom
        { get; set; }
        public string Prenom
        { get; set; }
        public string Telephone
        { get; set; }
        public Client(string cin,string nom,string prenom,string tel)
        {
            this._CIN = cin;
            this.nom = nom;
            this.prenom = prenom;
            this.telephone = tel;
        }
        public Client(string cin,string nom,string prenom)
        {
            this.nom = nom;
            this._CIN = cin;
            this.prenom = prenom;
        }
        public void afficher()
        {
            if (this.telephone ==" ")
            { 
                Console.WriteLine("le client ayant CIN: {0} est : {1} {2}", _CIN, nom, prenom);

            }
            else
                Console.WriteLine("le client ayant CIN: {0} est : {1} {2} son telephone est: {3}", _CIN, nom, prenom,telephone);


            }


        }
}
