﻿using System;

namespace exercice1
{
    class Equation
    {
        private double a, b, c, r1, r2, delta;
        public Equation(double a,double b,double c)
        {
            this.a= a;
            this.b = b;
            this.c = c;
        }
        public void claculRacines()
        {
            if (a != 0)
            {
                double discriminat = Math.Pow(this.b, 2) - (4 * this.a * this.c);
                this.delta = discriminat;
                double racineDelta = Math.Sqrt(this.delta);
                if (this.delta > 0)
                {
                    r1 = (-(this.b) + racineDelta) / (2 * this.a);
                    r2 = (-(this.b) - racineDelta) / (2 * this.a);
                }
                else if (this.delta == 0)
                {
                    r1 = -(this.b) / (2 * this.a);

                }
            }
            
        }
        
        public double A
        {
            get
            {
                return a;

            }
            set
            {
                if (value == 0)
                    Console.WriteLine("le programme ne traite pas le cas où a=0");
                else
                    a = value;
            }
        }
        public double B
        {
            get { return b; }
            set { b = value; }
        }
        public double C
        {
            get { return c; }
            set { c = value; }
        }


        public override string ToString()
        {
            if (a != 0)
            {
                if (this.delta > 0)
                    return "l'equation est:" + a + "x²+" + b + "x+" + c + "=0 \n les solutions sont : \n r1=" + r1 + "\n r2=" + r2;
                else if (this.delta == 0)
                    return "l'equation est:" + a + "x²+" + b + "x+" + c + "=0 \n la solution est unique : \n r=" + r1;

                else
                    return "l'equation est:" + a + "x²+" + b + "x+" + c + "=0 \n pas de racines reels";
            }
            else
                return "l'equation est:" + a + "x²+" + b + "x+" + c + "=0 \n le programme ne traite pas le cas où a=0";
        }

        /*  */
    }
    class Probleme
    {  
      
       public static void Main()
        {
           
            string r;
            Console.WriteLine("entrez les coefficients:");
            double a = double.Parse(Console.ReadLine());
            double b = double.Parse(Console.ReadLine());
            double c = double.Parse(Console.ReadLine());

            Equation monEquation = new Equation(a, b, c);
            monEquation.claculRacines();
        
            r = monEquation.ToString();

            Console.WriteLine(r);
          

        }
    }
}
