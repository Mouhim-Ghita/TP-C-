﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice3
{
    class Personne
    {
       private string _Nom;
       private string _Prénom;
       private  int _Age;

        public string Nom
        {
            get
            {
                return _Nom;

            }

        }
        public string Prénom
        {
            get
            {
                return _Prénom;
            }
        }
        public int Age
        {
            get { return _Age; }
            set
            {
                if (value <= 0)
                    Console.WriteLine("l'age saisi n'ai pas correct");
                else
                    _Age = value;
            }
        }
        public Personne(string nom,string prénom)
        {
            this._Nom = nom;
            this._Prénom = prénom;
        }
        public Personne(string nom,string prénom, int age)
        {
            this._Prénom = prénom;
            this._Nom = nom;
            this.Age = age;
        }
        public override string ToString()
        {
            return "le nom: " + _Nom + " le prénom: " + _Prénom + " l'age: " + _Age;
        }
       
        public virtual void afficher()
        {
            Console.Write("le nom est: {0} le prénom est : {1} l'âge est: {2}", _Nom, _Prénom, _Age);
        }

    }
}
