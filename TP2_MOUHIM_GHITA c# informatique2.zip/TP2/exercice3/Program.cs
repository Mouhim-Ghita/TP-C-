﻿using System;

namespace exercice3
{
    class Program
    {
        static void Main(string[] args)
        {
            //tableau des personnes:
            Personne[] tableau = new Personne[8];
            tableau[0] = new Employé("ali", "ahmed", 20, 1500);
            tableau[1] = new Employé("malki", "asma", 21, 1200);
            tableau[2] = new Employé("rhi", "guiez", 35, 13500);
            tableau[3] = new Employé("mouhim", "ali", 28, 2600);
            tableau[4] = new Employé("om lehani", "ghita", 29, 8500);
            tableau[5] = new Chef("pepe", "taylor", 47, 1954, "RH");
            tableau[6] = new Chef("rhiati", "fatiha", 50, 18600, "pdg");
            tableau[7] = new Directeur("mouhim", "ghita", 22, 95000, "PDG", "Mouhim pour informatique");
            //afficher le tableau par for:
            Console.WriteLine("affichage du tableau par for:");
            for(int i=0;i<tableau.Length;i++)
            {
                 string p = tableau[i].ToString();
                Console.WriteLine(i+"=>"+p);
               // Console.WriteLine(i+1+"=>"+tableau[i]);
            }
            //incrementation d'age
            tableau[4].Age = tableau[4].Age + 10;

            Console.WriteLine("/////// augmentation d'âge:");
            Console.WriteLine("4=>"+tableau[4]);

            ((Employé)tableau[6]).Salaire = 40000;
            ((Chef)tableau[6]).Service = "Marketting";

            Console.WriteLine("\n /////// changement de salaire et de service:");
            Console.WriteLine("6=>" + tableau[6]);
            Console.WriteLine("\n le tableau avec foreach:");
            //affichage avec foreach
            foreach (Personne i in tableau)
            {
                
                i.afficher();

            }
        }
    }
}
