﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice3
{
    class Chef:Employé
    {
        private string _Service;
        public string Service
        {
            get { return _Service; }
            set
            {
                _Service = value;
            }
        }
        public Chef(string nom,string prenom,int age, decimal salaire,string service):base(nom,prenom,age,salaire)
        {
            this._Service = service;
        }
        public override string ToString()
        {
            return base.ToString() + " le service est:"+Service;
        }
        public override void afficher()
        {
            base.afficher();
            Console.WriteLine("son service est:"+_Service);
        }
    }
}
