﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice3
{
    class Directeur:Chef
    {
        private string _Societe;
        public string Societe
        {
            get { return _Societe; }
        }
        public Directeur(string nom,string prenom,int age,decimal salaire,string service,string societe) : base(nom, prenom, age, salaire, service)
        {
          
            this._Societe = societe;
        }
        public override string ToString()
        {
            return base.ToString()+"  directeur de sociéte:"+_Societe;
        }
        public override void afficher()
        {
            base.afficher();
            Console.Write("directeur de societe :"+_Societe);
        }
    }
}
