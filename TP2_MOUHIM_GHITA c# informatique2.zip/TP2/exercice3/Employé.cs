﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice3
{
    class Employé:Personne
    {
        private decimal _Salaire;
        public decimal Salaire
        {
            get { return _Salaire; }
            set {

                if (value <= 0)
                    Console.WriteLine("cette employé n'a pas de salaire");
                else
                    _Salaire = value;
                }
        }
        public Employé(string nom,string prenom,int age,decimal salaire):base(nom,prenom,age)
        {
            this.Salaire = salaire;
            
        }
        public override string ToString()
        {
            return base.ToString() + " son salaire est: " + _Salaire;
        }
        public override void afficher()
        {
            base.afficher();
            Console.WriteLine(" son salaire est :"+_Salaire+"\t");
        }
    }
}
