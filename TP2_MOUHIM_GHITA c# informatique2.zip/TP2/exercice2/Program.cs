﻿using System;

namespace exercice2
{
    enum ville
    {
        Fès,Marrakech,Rabat,Casablanca
    }
    class Personne
    {
        private string nom;
        private string prenom;
        public int NumeroTelephone, age;
       private ville origine;
         static int c=0;
        public Personne()
        {
            if (c == 0) Console.WriteLine("Demarage du programme");
            Console.WriteLine("Construction de classe personne");
           
            c++;
        }
        public string Nom
        {
            get { return nom; }
        }
        public Personne(string nom,string prenom,int age,int tel,ville org)
        {
            
            if (c == 0) Console.WriteLine("Demarage du programme");
            this.nom = nom;
            this.prenom = prenom;
            this.age = age;
            this.NumeroTelephone = tel;
            this.origine = org;
          
            c++;
        }
        public Personne(Personne p)
        {
            if (c == 0) Console.WriteLine("Demarage du programme");

            this.nom = p.nom;
            this.prenom = p.prenom;
            this.age = p.age;
            this.NumeroTelephone = p.NumeroTelephone;
            this.origine = p.origine;
            c++;
        }
        public void changePersonne(int ancien_age)
        {
            this.age = ancien_age;
        }
        public void SavoirOrigine()
        {
            switch(this.origine)
            {
                case ville.Casablanca:
                    Console.WriteLine("la ville d'origine est Casablanca");
                    break;
                case ville.Fès:
                    Console.WriteLine("la ville d'origine est Fès");
                    break;
                case ville.Marrakech:
                    Console.WriteLine("la ville d'origine est Marrakech");
                    break;
                case ville.Rabat:
                    Console.WriteLine("la ville d'origine est Rabat");
                    break;
                
            }

        }
        public void afficher()
        {
            Console.WriteLine("le nom est:" +this.Nom+"\t le prenom est: "+prenom+"\t l'age est:"+age+"\t le numero de tel est:"+NumeroTelephone+"\t l'origine est:"+origine);
        }
        

        static void Main(string[] args)
        {
            Personne p = new Personne();
            Personne p1 = new Personne("mouhim", "ghita", 20, 0673615161, ville.Fès);
            Personne p2 = new Personne(p1);
            Console.WriteLine(p1.Nom);
            p.prenom = "";

            p1.SavoirOrigine();
            p2.changePersonne(26);
            p2.origine = ville.Casablanca;
            p2.prenom = "j";

            Console.WriteLine("la premiere personne est:\n");
            p1.afficher();
            Console.WriteLine("la deuxieme personne est:\n");

            p2.afficher();

        }
    }
}
