﻿using System;

namespace exercice4
{
    class Program
    {
        static void Main(string[] args)
        {
            Camion c1 = new Camion(2012, 80000);
            Voiture v1 = new Voiture(2008, 14000);
            Camion c2 = new Camion(1996, 7800);
            Voiture v2 = new Voiture(2017, 150000);
            c1.accelerer();
            v1.demarrer();
            v2.accelerer();
            c2.demarrer();

        }
    }
}
