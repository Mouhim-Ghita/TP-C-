﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice4
{
    class Camion:Vehicule
    {
        public Camion(int annee,double prix): base(annee, prix) { }
        public override void demarrer()
        {
            Console.WriteLine("le  démarage  du  camion "+ base.ToString());
            
        }
        public override void accelerer()
        {
            Console.WriteLine("l'acceleration   du  camion"+ base.ToString());
            
        }
    }
}
