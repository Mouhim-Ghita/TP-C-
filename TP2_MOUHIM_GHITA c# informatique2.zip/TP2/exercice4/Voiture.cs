﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice4
{
    class Voiture:Vehicule
    {
        public Voiture(int annee, double prix) : base(annee, prix) { }
        public override void demarrer()
        {
            Console.WriteLine("le  démarage  du  voiture " + base.ToString());

        }
        public override void accelerer()
        {
            Console.WriteLine("l'acceleration   du  voiture" + base.ToString());

        }
    }
}
