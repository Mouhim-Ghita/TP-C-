﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exercice4
{
    abstract class Vehicule
    {
        private int matricule, année; 
        private static  int mat=0;//on a utiliser une variable static pour qu'elle soit modifier chaque fois on fait appel au constructeur
        private double prix;
        public int Matricule
        {
            get;
        }
        public int Mat { get; }
        public int Année
        {
            get;
        }
        public double Prix
        {
            get;set;
        }
        public abstract void demarrer();
        public abstract void accelerer();
        public Vehicule(int année,double prix)
        {
            mat++;
            this.année=année;
            this.prix = prix;
            this.matricule = mat;
        }
        public override string ToString()
        {
            return " qui  est modele de :"+année+"  son matricule est: "+matricule+" son prix: "+prix;
        }
    }
}
