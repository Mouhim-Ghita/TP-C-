﻿namespace exercice1
{
    using System;
    class Mainclass
    {
        public static void Main()
        {
            double Tva = 20;
            string NomProduit;
            double PrixTtc;
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("\tentrez le nom de votre produit:");
            //Console.BackgroundColor = ConsoleColor.Yellow;
            NomProduit = Console.ReadLine();
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\tentrez le prix hors taxe de votre prduit:");
            Console.BackgroundColor = ConsoleColor.Black;
            double PrixSansTva = double.Parse(Console.ReadLine());
            PrixTtc = PrixSansTva + (Tva/100);
            Console.BackgroundColor = ConsoleColor.Magenta;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("\tle prix du {{{0}}} TTC est {1} Dhs",NomProduit, PrixTtc);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;





        }
    }
}
