﻿using System;

namespace exercice4
{
    class Program
    {
        static void NoteAppartenant()
        {
            int n;
            double s = 0 ,m=0,max=0,min=100;
            // double a;
            Console.WriteLine("entrez le nombre des appartenants du groupe");
            n = int.Parse(Console.ReadLine());
            double[] t = new double[n];
            if (n != 0)
            {
                Console.WriteLine("entrez la note de chaque participant:");
                for (int i = 0; i < n; i++)
                {
                    t[i] = double.Parse(Console.ReadLine());
                }
                Console.WriteLine("les notes sont:");
                foreach (double i in t)
                    Console.WriteLine(i);
                //la somme des notes:

                for (int i = 0; i < n; i++)
                    s = s + t[i];
                Console.WriteLine("la somme des notes est {0}", s);
                //la moyenne des notes



                m = s / n;
                Console.WriteLine("la moyenne du groupe est moyenne= {0}", m);

                //la plus grande note
                foreach (double i in t)
                {
                    if (i > max)
                        max = i;
                }
                //la plus petite note
                foreach (double i in t)
                {
                    if (i < min)
                        min = i;
                }
                Console.WriteLine("la plus grande note est {0}", max);
                Console.WriteLine("la plus petite note est {0}", min);
            }
            else
                Console.WriteLine("aucun participant dans le groupe");


        }
        static void Main(string[] args)
        {
            NoteAppartenant();
        }
    }
}
