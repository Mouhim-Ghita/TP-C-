﻿using System;

namespace exercice3
{
    class Program
    {
        static void nombreamstrang()
        {
            double i, j, k, nombre, a, b, c,s;
            Console.WriteLine("il existe 4 nombres d'amstrong qui sont:");
            for(i=1;i<=5;i++)//le nombre de centaine est compris entre 1 et 5 car les nombre d'amstrong sont entre 100 et 500
            {
                for(j=0;j<=9;j++)
                {
                    for(k=0;k<=9;k++)
                    {
                        a = Math.Pow(i, 3);
                        b = Math.Pow(j, 3);
                        c = Math.Pow(k, 3);
                        s = a + b + c;
                        nombre = 100 * i + 10 * j + k;
                        if (nombre == s)
                            Console.WriteLine("\t{0} = {1}^3 + {2}^3 + {3}^3 = {4}+{5}+{6}",nombre,i,j,k,a,b,c);


                    }
                }
            }
        }

        static void Main(string[] args)
        {
            nombreamstrang();
        }
    }
}
