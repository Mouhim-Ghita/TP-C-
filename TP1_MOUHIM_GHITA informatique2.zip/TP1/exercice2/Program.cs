﻿using System;

namespace exercice2
{
    class Program
    {
       static void solution1(double a,double b,double c)
        {
            double b2 = Math.Pow(b, 2);
            double delta=b2-4*(a*c);
            double x1, x2,x;
            if (a != 0)
            {
                if (delta > 0)
                {
                    double RacineDelta = Math.Sqrt(delta);
                    x1 = (-b + RacineDelta) / (2 * a);
                    x2 = (-b - RacineDelta) / (2 * a);

                    Console.WriteLine("l'équation admets deux solutions: \n x1={0} \n x2={1}", x1, x2);
                }
                else if (delta == 0)
                {
                    x = -(b) / (2 * a);
                    Console.WriteLine("l'équation admet une solution unique qui est x={0}", x);
                }
                else
                    Console.WriteLine("equation n'admet pas de solution dans l'ensemble R");
            }
            
        }
        static void solution2(double a,double b,double c)
        {
            double x;
            if (a == 0)
            {
                if (b != 0)
                {
                    x = (-c) / b;
                    Console.WriteLine("l'équation admet une solution unique qui est x={0}", x);
                }
                else
                {
                    if (c == 0)
                        Console.WriteLine("l'équation admet une infinité de solution");
                    else
                        Console.WriteLine("l'équation n'admet pas de solution car {0} est differrent de 0", c);
                }
            }

        }


         public static void Main()
        {
            double a, b, c;
            Console.WriteLine("entrez les coefficients de votre equation:");
            a = double.Parse(Console.ReadLine());
            b = double.Parse(Console.ReadLine());
            c = double.Parse(Console.ReadLine());
            Console.WriteLine("l'équation est:  {0}x²+({1})x+({2})=0",a,b,c);
            solution1(a, b, c);
            solution2(a, b, c);
           

        }
    }
}
