﻿using System;
using System.Reflection.Metadata.Ecma335;

namespace exercice6_2
{
    class Program
    {
        static void DateNumerique() {

              string[] t = { "/", ".", ":", "-" };
              bool pan = false;
              int p, r;
              Console.Write("entrez la date\t");
              var i = int.Parse(Console.ReadLine());
              string o = Console.ReadLine();
              for (int z = 0; z < t.Length; z++)
              {
                  if (o == t[z])
                      pan = true;
              }
              if (pan == true)
              {
                  p = int.Parse(Console.ReadLine());
                  var u = Console.ReadLine();
                  for (int z = 0; z < t.Length; z++)
                  {
                      if (u == t[z])
                          pan = true;
                  }
                  r = int.Parse(Console.ReadLine());
                  var j = (jours)i;
                  var k = (mois)r;
                  Console.WriteLine("{0} {1} {2}", j, p, k);
              }
              else
                  Console.WriteLine("erreur de saisie !!!!");
          



        }
     
            enum jours
        {
            lundi = 1,
            mardi = 2,
            mercredi = 3,
            jeudi = 4,
            vendredi = 5,
            samedi = 6,
            dimanche = 7
        }
        enum mois
        {
            janvier=1,fevrier=2,mars=3,avril=4,mai=5,juin=6,juillet=7,août=8,septembre=9,octobre=10,novembre=11,decembre=12
        }
        

      
        static void Main()
        {
            /*
            var j = (jours)1;
            Console.WriteLine(j)*/
            DateNumerique();
         /*madame j'ai essayé de lai saisir dans une seule ligne mais ça me donne
          un problème pour cela je dois revenir à la ligne pour saisir l'autre caractère */ 

               
        }
    }
}
