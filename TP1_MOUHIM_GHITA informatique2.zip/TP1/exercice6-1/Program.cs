﻿using System;

namespace exercice6_1
{
    class Program
    {
        static String compresser(String p)
        {
            String s="";
            
            char[] tab=p.ToCharArray();//ici on transforme le string entrez en tableau des caractères
            for(int i=0;i<p.Length;i++)
            {
                if (tab[i].Equals(' '))
                    continue;
                else
                    s+= tab[i];

            }
            return s;

        }
        static string InverserM1(string p)
        {
            string caratere = "";
            for(int i=p.Length-1;i>=0;i--)
            {
                caratere = caratere + p[i];
            }
            return caratere;
        }
        static char[] InverserM2(string p)
        {
            char[] tableau = new char[p.Length];
            for (int i = 0, j = p.Length-1;i<=(p.Length)/2;i++,j--)
            {
                tableau[i] = p[j];
                tableau[j] = p[i];
            }

            return tableau;
        }
        static void Main(string[] args)
        {
            string p;
            Console.WriteLine("entrez votre phrase");
            p = Console.ReadLine();
            Console.WriteLine("\n\t la compression:");
            string s = compresser(p);
            Console.WriteLine(s);
            Console.WriteLine("\n \t premiere methode d'inverser");
            string o = InverserM1(s);
            Console.WriteLine(o);
            Console.WriteLine("\n \t deuxieme methode d'inverser");
            char[] t = new char[s.Length];
            t = InverserM2(s);
            for (int i = 0; i < t.Length; i++)
             Console.Write(t[i]);
            

            if (s == o || s.Equals(t))
                Console.WriteLine("\nle mot est palindrome");
            else
                Console.WriteLine("\n le mot n'est pas palindrome");
        }
    }
}
