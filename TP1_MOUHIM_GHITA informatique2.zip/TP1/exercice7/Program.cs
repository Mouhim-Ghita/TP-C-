﻿using System;

namespace exercice7
{
    class Program
    {
        static void IncTab(int[] tableau)
        {
            for (int i = 0; i < tableau.Length; i++)
                tableau[i]++;
        }
        static int[] IncNewTab(int[] tableau)
        {
            int[] tableau1 = new int[tableau.Length];
            for (int i = 0; i < tableau.Length; i++)
            {
                tableau1[i] = tableau[i]+1;
            }

            return  tableau1;

        }
        static void IncNewTabOut(int[] tableau,out int[] tableau1)
        {
            tableau1 = new int[tableau.Length];
            for (int i = 0; i < tableau.Length; i++)
            { tableau1[i] = tableau[i]+1; }
        }
        static void Main(string[] args)
        {
            int[] t = { 6, 9, 8, 3 };
            Console.WriteLine("le tableau est:");
            foreach (int i in t)
                Console.Write(i+"\t");
            Console.WriteLine("\n \tpremiere methode d'icrementation:");
           IncTab(t);
           Console.WriteLine("\nle nouveau tableau est:");
           foreach (int i in t)
             Console.Write(i+"\t");
            Console.WriteLine("\n \t deuxieme methode d'icrementation:");
            int[] table;
           table= IncNewTab(t);
            Console.WriteLine("\nle nouveau tableau est:");
            foreach (int i in table)
                Console.Write(i + "\t");

             Console.WriteLine("\n \t troisieme methode d'icrementation:");
             int[] tableau;

             IncNewTabOut(t,out tableau);
             Console.WriteLine("\nle nouveau tableau est:");
             foreach (int i in tableau)
                 Console.Write(i + "\t");

        }
    }
}
