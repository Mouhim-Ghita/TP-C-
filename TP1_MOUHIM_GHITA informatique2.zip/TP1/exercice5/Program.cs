﻿using System;

namespace exercice5
{
    class Program
    {
        //methode de remplir le tableau
        static void RemplirTableau(int[] t)
        {
            Random j = new Random();
            for(int i=0;i<t.Length;i++)
            {
                t[i] = j.Next(1, 100);
            }
        }
        //afficher tableau
        static void afficherTableau(int[] t)
        {
            foreach (int i in t)
                Console.Write(i+"\t");
        }
        static void rechercheTableau(int[] t)
        {
            int n,compteur=0;
            bool p=false;
            Console.WriteLine("\nentrez le nombre à rechercher:");
            n = int.Parse(Console.ReadLine());
            for(int i=0;i<t.Length;i++)
            {
                if (n == t[i])
                {
                    compteur = i;
                    p = true;
                }
                
               
            }
            if(p==true)
            Console.WriteLine("le nombre chercher se trouve dans l'indice: {0}",compteur);
            else

                Console.WriteLine("le nombre chercher n'existe pas");


        }
        static void Main(string[] args)
        {
            int[] t = new int[20];
            RemplirTableau(t);
            afficherTableau(t);
            rechercheTableau(t);
        }
    }
}
